#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define tamano 100

void bubble(int arr[]);

int main(){
	int arr[tamano], i;

	srand(time(NULL));
	printf("Elementos aleatorios:\n");
	for(i=0; i<tamano; i++){
		arr[i] = rand()%100; 
		printf("%d\t", arr[i]);
	}

	printf("Ordenados:\n");
	bubble(arr);

return 0;
}

void bubble(int arr[]){
	int i, j, aux;
	for(i=1; i<tamano; i++)
		for(j=0; j<(tamano-1); j++){
			if(arr[j] > arr[j+1]){
				aux = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = aux;
			}
		}

	for(i=0; i<tamano; i++)
		printf("%d\t", arr[i]);
}