#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void quick_sort(int arr[], int lower, int upper);

int main(int argc, char *argv[]){
	int size = atoi(argv[1]);
	int i, arr[size];

	srand(time(NULL));

	printf("\nArreglo aleatorio:\n");
	for(i=0; i<size; i++){
		arr[i] = rand()%100;
		printf("%d\t", arr[i]);
	}
	printf("\n");
	quick_sort(arr, 0, size);

	printf("\nArreglo ordenado:\n");
	for(i=0; i<size; i++)
		printf("%d\t", arr[i]);

return 0;
}

void quick_sort(int arr[], int lower, int upper){
	int tmp;
	int mid = (upper + lower)/2;
	int pivote = arr[mid];
	int tlower = lower;
	int tupper = upper;

	while(tlower <= tupper){
		while(arr[tlower] < pivote)
			tlower++;
		while(arr[tupper] > pivote)
			tupper--;
		if(tlower <= tupper){
			tmp = arr[tlower];
			arr[tlower] = arr[tupper];
			arr[tupper] = tmp;
			tupper--;
			tlower++;
		}
	}

	if(lower < tupper)
		quick_sort(arr, lower, tupper);
	if(tlower < upper)
		quick_sort(arr, tlower, upper);
}