#include <stdio.h>
#include <stdlib.h>

void sumar(int N);

int main(int argc, char *argv[]){
	int N = atoi(argv[1]);
	printf("\nPrograma que calcula la suma de los primeros N numeros:");
	printf("\nNumero de entrada:\t%d", N);

	sumar(N);

return 0;
}

void sumar(int N){
	int i, suma=0;
	for(i=1; i<=N; i++)
		suma += i;

	printf("\nSuma de los primeros %d:\t%d\n\n", N, suma);
}