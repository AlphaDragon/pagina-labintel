#include <stdio.h>
#include <stdlib.h>

void sumar(int N);
int factorial(int N);

int main(int argc, char *argv[]){
	int N = atoi(argv[1]);

	printf("\nPrograma que suma los primeros N factoriales:");
	printf("\n\tNumero entrada: %d", N);

	sumar(N);

return 0;
}

int factorial(int N){
	int i;
	for(i=(N-1); i>0; i--)
		N *= i;
	//printf("\n\t\t\tfactorial\t%d", N);
	return N;
}

void sumar(int N){
	int i, suma=0;
	for(i=1; i<=N; i++){
		suma += factorial(i);
		//printf("\n\t\tsuma %d\t%d", i, suma);
	}
	printf("\n\tResultado = %d\n", suma);
}