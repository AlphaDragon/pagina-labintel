#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

long ser_fibo(long num);

int main(int argc, char *argv[]){
	   int numero;
       long res;
       double start, stop;
       
       numero = atoi(argv[1]);

       start = omp_get_wtime();
       res=ser_fibo(numero);
       stop = omp_get_wtime();
       
       printf("\n\nEl resultado secuencial:\t%ld", res);
       printf("\n\tTiempo en serie:  %lf segundos\n", stop-start);
       
return 0;
}

long ser_fibo(long num){
	long i=1, j=0;
	int k;
	long temp;
	for(k=0; k<num; k++){
		temp = i + j;
		i = j;
		j = temp;
	}
	return j;
}



