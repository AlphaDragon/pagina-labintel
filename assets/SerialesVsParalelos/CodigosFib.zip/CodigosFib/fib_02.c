#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

long par_fibo(long num);

int main(int argc, char *argv[]){
	int numero;
       long res;
       double start, stop;

       numero = atoi(argv[1]);

       start = omp_get_wtime();  
       res=par_fibo(numero);
       stop = omp_get_wtime();
       printf("\nEl resultado recursivo:\t%ld", res);   
       printf("\n\tTiempo con recursividad:  %lf segundos\n", stop-start);
       
return 0;
}

long par_fibo(long num){
       if(num < 2)
              return num;
       else
              return par_fibo(num-1) + par_fibo(num-2);
}



