#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

long par2_fibonacci(long num);

int main(int argc, char *argv[]){
	int numero, threads;
       long res;
       double start, stop;

       numero = atoi(argv[1]);
       threads = atoi(argv[2]);

       omp_set_num_threads(threads);
       
       start = omp_get_wtime();  
       #pragma omp parallel
       {
       	#pragma omp single nowait
              {
       		res=par2_fibonacci(numero);
              }
       }
       stop = omp_get_wtime();

       printf("\nEl resultado paralelo:\t%ld", res);   
       printf("\n\tTiempo en paralelo con herramienta:  %lf segundos\n\n", stop-start);
       
return 0;
}

long par2_fibonacci(long num){
       long i, j, res;
       if(num < 2)
              return num;
       else{
       	      #pragma omp task shared(i)
       	      i = par2_fibonacci(num-1);
       	      #pragma omp task shared(j)
       	      j = par2_fibonacci(num-2);
       	      #pragma omp taskwait
              res = i+j;
              return res;
       }
}

