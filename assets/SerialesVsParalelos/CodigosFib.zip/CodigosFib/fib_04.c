#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <math.h>

#define raiz_5 sqrt(5)

int main(int argc, char *argv[]){
	int numero = atoi(argv[1]);
	double start, stop, a, b, res;

	start = omp_get_wtime();
	a =  1/raiz_5 * pow((1 + raiz_5)/2, numero);
	b =  1/raiz_5 * pow((1 - raiz_5)/2, numero);
	res = a - b;
	stop = omp_get_wtime();

    printf("\nEl resultado con formula:\t%.0lf", res);   
    printf("\n\tTiempo con formula:  %lf segundos\n", stop-start);
       

return 0;
}