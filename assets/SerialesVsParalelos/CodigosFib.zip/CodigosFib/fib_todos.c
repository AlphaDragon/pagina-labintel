#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

long ser_fibonacci(long num);
long par_fibonacci(long num);
long par2_fibonacci(long num);

int main(int argc, char *argv[]){
	int numero, threads;
       long res;
       double start, stop;

       numero = atoi(argv[1]);
       threads = atoi(argv[2]);

       start = omp_get_wtime();
       res=ser_fibonacci(numero);
       stop = omp_get_wtime();
       printf("\n\nEl resultado secuencial:\t%ld", res);
       printf("\n\tTiempo en serie:  %lf segundos\n", stop-start);
	    
       start = omp_get_wtime();  
       res=par_fibonacci(numero);
       stop = omp_get_wtime();
       printf("\nEl resultado paralelo:\t%ld", res);   
       printf("\n\tTiempo en paralelo sin herramienta:  %lf segundos\n", stop-start);
       
       omp_set_num_threads(threads);
       
       start = omp_get_wtime();  
       #pragma omp parallel
       {
       	#pragma omp single nowait
              {
       		res=par2_fibonacci(numero);
              }
       }

       stop = omp_get_wtime();
       printf("\nEl resultado paralelo:\t%ld", res);   
       printf("\n\tTiempo en paralelo con herramienta:  %lf segundos\n\n", stop-start);
       
return 0;
}

long ser_fibonacci(long num){
	long i=1;
	long j=0;
	long k;
	long temp;
	for(k=0; k<num; k++){
		temp = i + j;
		i = j;
		//printf("Parcial  %d:\t%d\n", k, j);
		j = temp;
	}
	return j;
}


long par_fibonacci(long num){
       long i, j, res;
       if(num < 2)
              return num;
       else{
       	      i = par_fibonacci(num-1);
       	      j = par_fibonacci(num-2);
              res = i+j;
              return res;
       }
}

long par2_fibonacci(long num){
       long i, j, res;
       if(num < 2)
              return num;
       else{
       	      #pragma omp task shared(i)
       	      i = par_fibonacci(num-1);
       	      #pragma omp task shared(j)
       	      j = par_fibonacci(num-2);
       	      #pragma omp taskwait
              res = i+j;
              return res;
       }
}





