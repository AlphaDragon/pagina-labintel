#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

void calculo_pi();

int main(int argc, char *argv[]){

	int threads= atoi(argv[1]);
	omp_set_num_threads(threads);

	calculo_pi();

return 0;
}


void calculo_pi(){

	int i;
	double height,x=0.0, store=0.0,base;
	double start, stop;

	int intervals=100000000;
	base=(double)(1.0/intervals);

	start = omp_get_wtime();  
	#pragma omp parallel for reduction(+:store) private(i, x, height)
	for (i=0; i<intervals; i++) {
		x = i * base;
		height = 4/(1 + x * x);
		store += base * height;
		x+=base;
	}
	stop = omp_get_wtime();
 
    printf("\n\tTiempo en paralelo:  %lf segundos\n\n", stop-start);


	printf("PI (single th) = %lf \n",store);

}

